import os
import sys
import pyttsx3

engine = pyttsx3.init()
engine.say('Welcome to ThinkRobo. Please look into the camera, Once you can see your picture Please press space + esc + enter for generating ID Card')
engine.runAndWait()
