import os
import sys
import pyttsx3

engine = pyttsx3.init()
engine.say('hello, I am Your Virtual Receptionist. Please Click on "CLICK ME" then Select your choice. I will be happy to serve you today ')
engine.runAndWait()
