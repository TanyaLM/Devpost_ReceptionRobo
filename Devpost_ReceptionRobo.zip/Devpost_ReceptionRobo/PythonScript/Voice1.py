import os
import sys
import pyttsx3

engine = pyttsx3.init()
engine.say('hello, We Found Your Article Please collect it from Drawer 101. Thank You Have A Nice Day')
engine.runAndWait()
