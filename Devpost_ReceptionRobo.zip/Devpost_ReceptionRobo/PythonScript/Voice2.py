import os
import sys
import pyttsx3

engine = pyttsx3.init()
engine.say('We updated Our Database please submit this to counter 101. Thank You')
engine.runAndWait()
