import os
import sys
import pyttsx3

engine = pyttsx3.init()
engine.say('Please wait. I am waiting for the approval from respective Person.')
engine.runAndWait()
